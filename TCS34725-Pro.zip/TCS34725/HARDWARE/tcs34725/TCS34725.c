/* 
  Auther:Cao Qiyuan
	Date: 2021/07/24
  Project��TCS34725.c
 	Funtion��TCS34725��ɫ������IIC���ݶ�ȡ����
     			--SCL PC10
  				--SDA PC11
 */
#include <stm32f10x.h>
#include "TCS34725.h"
#include "delay.h"
//TCS34725
#define Pt_TCS34725_SDA_rcc 				RCC_APB2Periph_GPIOC
#define Pt_TCS34725_SDA_gpio 				GPIOC
#define Pt_TCS34725_SDA_pin 				GPIO_Pin_11

#define Pt_TCS34725_SCL_rcc 				RCC_APB2Periph_GPIOC
#define Pt_TCS34725_SCL_gpio 				GPIOC
#define Pt_TCS34725_SCL_pin 				GPIO_Pin_10

#define  SDA_TCS34725_IN     {GPIOC->CRH&=0XFFFF0FFF;GPIOC->CRH|=8<<12;}  //SET  IN
#define  SDA_TCS34725_OUT    {GPIOC->CRH&=0XFFFF0FFF;GPIOC->CRH|=3<<12;}  //SET  OUT

#define Read_TCS34725_SDA  GPIO_ReadInputDataBit(Pt_TCS34725_SDA_gpio,Pt_TCS34725_SDA_pin)//��ȡ����ֵ

#define  SDA_H         GPIO_SetBits(Pt_TCS34725_SDA_gpio,Pt_TCS34725_SDA_pin)  //�á�1��
#define  SDA_L         GPIO_ResetBits(Pt_TCS34725_SDA_gpio,Pt_TCS34725_SDA_pin)   //�塰0��
#define  SCL_H         GPIO_SetBits(Pt_TCS34725_SCL_gpio,Pt_TCS34725_SCL_pin)   //�á�1��
#define  SCL_L         GPIO_ResetBits(Pt_TCS34725_SCL_gpio,Pt_TCS34725_SCL_pin)  //�塰0��
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
//��������
_TCS3472_HSL _TCS3472_HSL_DATA;
//��������
void Color_tcs34725_Init(void);
void TCS34725_Write_addr(u8 Address, u8 dat);
u8 TCS34725_Read_addr(u8 Address);
void Capture_RGB(void);
void White_Banlance_Init(void);
void Printf_ColorRGB(void);
//�ڲ�����
void I2CStart(void);
void I2Cask(void);
void I2CStop(void);
void I2CWrByte(u8 oneByte);
void IIC_MASTERACK (void);

void ToHSL(const float red, const float green, const float blue)
{
	float fmax, fmin;
	fmax = MAX(MAX(red, green), blue);
	fmin = MIN(MIN(red, green), blue);
	_TCS3472_HSL_DATA.luminance = fmax;
	if (fmax > 0)
		_TCS3472_HSL_DATA.saturation = (fmax - fmin) / fmax;
	else
		_TCS3472_HSL_DATA.saturation = 0;
	if (_TCS3472_HSL_DATA.saturation == 0)
		_TCS3472_HSL_DATA.hue = 0;
	else
	{
		if (fmax == red)
		_TCS3472_HSL_DATA.hue = (green - blue) / (fmax - fmin);
		else if (fmax == green)
		_TCS3472_HSL_DATA.hue = 2 + (blue - red) / (fmax - fmin);
		else
		_TCS3472_HSL_DATA.hue = 4 + (red - green) / (fmax - fmin);
		_TCS3472_HSL_DATA.hue = _TCS3472_HSL_DATA.hue / 6;
		if (_TCS3472_HSL_DATA.hue < 0) _TCS3472_HSL_DATA.hue += 1;
	}
}

/*************************************************
             I2C���ƺ���
*************************************************/
//������ʼ������
void Port_Init(void) //IO��ʼ��
{ 
 	GPIO_InitTypeDef GPIO_InitStructure;
 
 	RCC_APB2PeriphClockCmd(Pt_TCS34725_SDA_rcc|Pt_TCS34725_SCL_rcc,ENABLE);//ʹ��PORTA,PORTEʱ��
	
	GPIO_InitStructure.GPIO_Pin  = Pt_TCS34725_SDA_pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(Pt_TCS34725_SDA_gpio, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin  = Pt_TCS34725_SCL_pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(Pt_TCS34725_SCL_gpio, &GPIO_InitStructure);	
}

void I2CStart(void)//��ʼ�ź�
{
		SDA_TCS34725_OUT;
    SCL_H;
//		delay_us(10);
    delay_us(50);
    SDA_H;
    delay_us(10);
    SDA_L;
    delay_us(10);
    SCL_L;
}
void I2CStop(void) //ֹͣ�ź�
{
		SDA_TCS34725_OUT;
    SDA_L;
    delay_us(100);
    SCL_H;
    delay_us(10);
    SDA_H;
    delay_us(100);
    SCL_L;
    delay_us(100);
    SDA_L;
    delay_us(10);
}

void I2Cask(void) //ACK�ź�
{
    u8 timeout = 1;
    SDA_TCS34725_IN;          //SDAת��Ϊ����
    SCL_L;
    while((Read_TCS34725_SDA) && (timeout <= 10)) //�ȴ�SDA���ء�0����ƽ
    {
        timeout++;
    }
    SCL_H;
    delay_us(10);
    SCL_L;
    SDA_TCS34725_OUT;          //SDAת��Ϊ���
}
/*******************************************************************************
* �� �� ��         :IIC_MASTERACK()
* ��������         :MCUӦ���ź�        
* ��    ��         :��
* ��    ��         :��
*******************************************************************************/ 
void IIC_MASTERACK (void)//��Ӧ�ź�
{
  
		SDA_TCS34725_OUT;    
    SCL_L;
    delay_us(10);
    SDA_L;
    delay_us(100);
    SCL_H;
    delay_us(10);
    SCL_L;
    delay_us(10);      
}
void I2CWrByte(u8 oneByte) //дһ���ֽڸ�λ��ǰ����λ�ں�
{
    u8 i;
		delay_us(10);
		SDA_TCS34725_OUT;
    SCL_L;
    for(i = 0; i < 8; i++)
    {
        if(oneByte & 0x80)
            SDA_H;
        else
            SDA_L;

        delay_us(10);
        SCL_H;
        delay_us(10);
        SCL_L;
        oneByte <<= 1;
    }
		delay_us(10);
}
u8 I2CReadByte() //дһ���ֽڸ�λ��ǰ����λ�ں�
{
    u8 dat, i;
    dat = 0;
    SDA_TCS34725_IN;          //SDAת��Ϊ����	
		delay_us(10);	
    SCL_L;
    for(i = 0; i < 8; i++)
    {
        SCL_H;
        dat = dat << 1;
        if(Read_TCS34725_SDA)
        {
            dat++;
        }
        delay_us(10);
        SCL_L;
        delay_us(10);
    }
		delay_us(10);
		SDA_TCS34725_OUT;
    return dat ;
}

void TCS34725_Write_addr(u8 Address,u8 dat) //
{
    I2CStart();
    I2CWrByte(COLOR_ADDR_Device); 
    I2Cask();
    I2CWrByte(Address);	
    I2Cask();
    I2CWrByte(dat);
    I2Cask();
    I2CStop();
}

u8 TCS34725_Read_addr(u8 Address)  //
{
		u8 rev;

    I2CStart();
    I2CWrByte(COLOR_ADDR_Device);
    I2Cask();
		I2CWrByte(Address);
		I2Cask();
		I2CStart();
		I2CWrByte(COLOR_ADDR_Device|0x01);	
    I2Cask();
		rev = I2CReadByte();
    I2CStop();
    return(rev);
}

_RGBC_V RGB_V;
void Capture_RGB(void)
{
	u8 i,count=3;
	u8 status;
	u16 tt[4];
	u32 r=0,g=0,b=0,c=0;
	TCS34725_Write_addr(COLOR_ADDR_WTIME,0xFF);		//���õȴ�ʱ��2.4ms
	TCS34725_Write_addr(COLOR_ADDR_ATIME,0xF6);		//���ü���ʱ��
	TCS34725_Write_addr(COLOR_ADDR_CONTROL,0x02);	//RGBֵ���汶������	
	for(i=0;i<count;i++)
	{
		TCS34725_Write_addr(COLOR_ADDR_ENABLE,0x0B);//�������ݲɼ�
		delay_ms(50);
		status = TCS34725_Read_addr(COLOR_ADDR_ENABLE) & ~0x02;
		TCS34725_Write_addr(COLOR_ADDR_ENABLE,status);
		
    I2CStart();
    I2CWrByte(COLOR_ADDR_Device);
    I2Cask();
		I2CWrByte(COLOR_ADDR_CDATAL);
		I2Cask();
		I2CStart();
		I2CWrByte(COLOR_ADDR_Device|0x01);	
		I2Cask();
		tt[0] = I2CReadByte();
		IIC_MASTERACK();
		tt[0] |= I2CReadByte()<<8;
		IIC_MASTERACK();
		tt[1] = I2CReadByte();
		IIC_MASTERACK();
		tt[1] |= I2CReadByte()<<8;
		IIC_MASTERACK();
		tt[2] = I2CReadByte();
		IIC_MASTERACK();
		tt[2] |= I2CReadByte()<<8;
		IIC_MASTERACK();
		tt[3] = I2CReadByte();
		IIC_MASTERACK();
		tt[3] |= I2CReadByte()<<8;
		I2CStop();
		
		c += tt[0];
		r += tt[1];
		g += tt[2];
		b += tt[3];
	}
	RGB_V.Green = g/count;	
	RGB_V.Blue = b/count;
	RGB_V.Red = r/count;
	RGB_V.Clear = c/count;	
}
//��ƽ�����ݲɼ�
_WhiteBanlance_Gene GENE={451,596,511,1570};		//��ʼֵ
void White_Banlance_Init(void)
{
	Capture_RGB();
	GENE.Rgene = RGB_V.Red;
	GENE.Ggene = RGB_V.Green;
	GENE.Bgene = RGB_V.Blue;
	GENE.Cgene = RGB_V.Clear;
}

_TCS3472_RGBC RGB;
void Printf_ColorRGB(void)
{
	Capture_RGB();
	RGB.Red = RGB_V.Red*255/GENE.Rgene;
	RGB.Green = RGB_V.Red*255/GENE.Ggene;
	RGB.Blue = RGB_V.Red*255/GENE.Bgene;
	
	if(RGB.Red>255)		RGB.Red = 255;
	if(RGB.Green>255)	RGB.Green = 255;
	if(RGB.Blue>255)	RGB.Blue = 255;	
	ToHSL(RGB.Red, RGB.Green, RGB.Blue);	
}
void Color_tcs34725_Init(void)
{
	Port_Init();
	TCS34725_Write_addr(COLOR_ADDR_WTIME,0xFF);		//���õȴ�ʱ��2.4ms
	TCS34725_Write_addr(COLOR_ADDR_ATIME,0xF6);		//���ü���ʱ��24ms��������ֵ10240
	TCS34725_Write_addr(COLOR_ADDR_CONTROL,0x02);	//RGBֵ���汶������
	TCS34725_Write_addr(COLOR_ADDR_ENABLE,0x09);	//�رղɼ�ͨ��
	TCS34725_Write_addr(COLOR_ADDR_AILTL,0x0A);
	TCS34725_Write_addr(COLOR_ADDR_AILTH,0x00);
	TCS34725_Write_addr(COLOR_ADDR_AIHTL,0xFF);
	TCS34725_Write_addr(COLOR_ADDR_AIHTH,0x1F);
	TCS34725_Write_addr(COLOR_ADDR_PERS,0x06);	
}
